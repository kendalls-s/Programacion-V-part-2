﻿namespace CarnetDigitalWeb.Models
{
    public class RolRequest
    {
        public string Nombre { get; set; } = string.Empty;

        public List<int> Pantallas { get; set; } = new();
    }
}